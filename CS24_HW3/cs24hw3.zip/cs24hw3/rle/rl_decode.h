char * rl_decode(char *input_data, int input_length, int *output_length);

