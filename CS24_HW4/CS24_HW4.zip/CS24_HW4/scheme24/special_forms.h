#ifndef SPECIAL_FORMS_H
#define SPECIAL_FORMS_H

#include "types.h"

Value * eval_special_form(Environment *env, Value *expr);

#endif /* SPECIAL_FORMS_H */

